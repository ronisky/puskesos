<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title> Sistem Informasi Organisasi Kemahasiswaan</title>
    <!-- Bootstrap core CSS -->
    <link href="<?= base_url('assets/'); ?>home/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fontawesome CSS -->
    <link href="<?= base_url('assets/'); ?>home/css/all.css" rel="stylesheet">
    <!-- Owl Carousel CSS -->
    <link href="<?= base_url('assets/'); ?>home/css/owl.carousel.min.css" rel="stylesheet">
    <!-- Owl Carousel CSS -->
    <link href="<?= base_url('assets/'); ?>home/css/jquery.fancybox.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?= base_url('assets/'); ?>home/css/style.css" rel="stylesheet">

    <link href="<?= base_url('assets/home/images/'); ?>sttbandung.ico" rel=" shortcut icon">
    <!-- Favicon and touch icons -->

    <!-- Dropify -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>plugins/dropify/css/dropify.min.css">

    <!-- summernote -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>plugins/summernote/summernote-bs4.css">
</head>

<body>